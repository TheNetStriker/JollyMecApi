// This header file is in the public domain.

#ifndef _mk20dx128_h_
#define _mk20dx128_h_
#include "kinetis.h"  // mk20dx128.h renamed to kinetis.h
#endif
